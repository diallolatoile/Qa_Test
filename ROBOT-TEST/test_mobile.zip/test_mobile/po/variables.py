REMOTE_URL =    "http://127.0.0.1:4723"        
PLATFORM_NAME =  "Android"
PLATFORM_VERSION = "16.0"
DEVICE_NAME =     "Pixel a3"
APP_PACKAGE =          "sn.sonatel.dsi.moussa.wade.moussawade"
APP_ACTIVITY   =    ".MainActivity"
AUTOMATION_NAME = "uiautomator2"

