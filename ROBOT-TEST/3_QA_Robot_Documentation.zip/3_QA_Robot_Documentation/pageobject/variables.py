URL = "https://selenium-practice.netlify.app"
BROWSER = "Chrome"
DATE = "06/09/1999"
LANG = "en"
